<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class About_us extends CI_Controller {

	public function index()	{
		$this->load->view('about_us/index');
	}

}

/* End of file Home.php */
/* Location: ./application/modules/home/controllers/Home.php */